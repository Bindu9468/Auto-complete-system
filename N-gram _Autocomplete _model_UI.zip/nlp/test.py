from collections import defaultdict

class NgramAutocomplete:
    def __init__(self, n=3):
        self.n = n
        self.ngram_index = defaultdict(list)

    def generate_ngrams(self, text):
        """
        Generate n-grams from the given text.
        """
        words = text.split()
        ngrams = zip(*[words[i:] for i in range(self.n)])
        return [" ".join(ngram) for ngram in ngrams]

    def build_index(self, corpus):
        """
        Build the n-gram index for the given corpus.
        """
        for i, sentence in enumerate(corpus):
            ngrams = self.generate_ngrams(sentence)
            for ngram in ngrams:
                self.ngram_index[ngram].append(i)

    def search(self, query):
        """
        Search for the n-grams that match the given query.
        """
        suggestions = []
        for ngram in self.ngram_index:
            if ngram.startswith(query):
                suggestions.extend(self.ngram_index[ngram])
        return suggestions

# Example usage
if __name__ == "__main__":
    # Sample corpus
    corpus = [
        "The quick brown fox jumps over the lazy dog",
        "The quick brown fox",
        "The quick runner",
        "A fast brown fox jumps",
        "Quick brown dogs are fun",
        "Dogs are loyal animals"
    ]

    # Initialize and build the n-gram index
    autocomplete = NgramAutocomplete(n=2)  # Using 2-grams
    autocomplete.build_index(corpus)

    # Query
    query = "quick brown"
    results = autocomplete.search(query)

    # Display results
    for index in results:
        print(corpus[index])
