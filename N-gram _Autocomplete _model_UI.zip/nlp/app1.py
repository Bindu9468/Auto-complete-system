from collections import defaultdict
from flask import Flask, jsonify, request, render_template
import re
from fuzzywuzzy import process

app = Flask(__name__)

class NgramAutocomplete:
    def __init__(self, n=3):
        self.n = n
        self.ngram_index = defaultdict(list)

    def generate_ngrams(self, text):
        words = text.split()
        ngrams = zip(*[words[i:] for i in range(self.n)])
        return [" ".join(ngram) for ngram in ngrams]

    def build_index(self, corpus):
        for i, sentence in enumerate(corpus):
            ngrams = self.generate_ngrams(sentence.lower())
            for ngram in ngrams:
                self.ngram_index[ngram].append(sentence)

    def search(self, query):
        query = query.lower()  # Convert query to lowercase for case-insensitive search
        suggestions = []

        # First pass: Exact n-gram startswith matches
        for ngram in self.ngram_index:
            if ngram.startswith(query):
                suggestions.extend(self.ngram_index[ngram])

        # Second pass: Partial matching (substring match)
        if not suggestions:
            for ngram in self.ngram_index:
                if query in ngram:
                    suggestions.extend(self.ngram_index[ngram])

        # Return ranked results based on uniqueness
        return self.rank_results(list(set(suggestions)))

    def rank_results(self, suggestions):
        """
        Rank results based on the relevance of the matches.
        Here, we simply sort by the length of the suggestion, but you could implement more complex logic,
        such as frequency-based ranking or proximity to the start of the phrase.
        """
        return sorted(suggestions, key=lambda x: len(x))

    def search(self, query):
        query = query.lower()
        suggestions = []

        # Exact matches
        for ngram in self.ngram_index:
            if ngram.startswith(query):
                suggestions.extend(self.ngram_index[ngram])

        # Partial matches
        if not suggestions:
            for ngram in self.ngram_index:
                if query in ngram:
                    suggestions.extend(self.ngram_index[ngram])

        # Fuzzy matches if the exact match is unsuccessful
        if not suggestions:
            all_ngrams = list(self.ngram_index.keys())
            fuzzy_matches = process.extract(query, all_ngrams, limit=5, scorer=fuzz.partial_ratio)
            for match, score in fuzzy_matches:
                if score > 70:  # Use a threshold to limit how fuzzy the matches are
                    suggestions.extend(self.ngram_index[match])

        return self.rank_results(list(set(suggestions)))


# Initialize the autocomplete system and build the index
autocomplete = NgramAutocomplete(n=2)
corpus = [
    "The quick brown fox jumps over the lazy dog",
    "The quick brown fox",
    "The quick runner",
    "A fast brown fox jumps",
    "Quick brown dogs are fun",
    "Dogs are loyal animals"
]
autocomplete.build_index(corpus)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/autocomplete', methods=['GET'])
def autocomplete_route():
    query = request.args.get('query', '')
    if len(query) < 2:
        return jsonify([])

    suggestions = autocomplete.search(query)
    return jsonify(suggestions[:5])  # Limit to 5 suggestions

if __name__ == "__main__":
    app.run(debug=True)
