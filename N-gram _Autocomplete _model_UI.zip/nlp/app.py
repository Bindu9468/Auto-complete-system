from flask import Flask, render_template, request, jsonify
import nltk
from nltk.util import ngrams
from collections import defaultdict, Counter

app = Flask(__name__)

# Sample text corpus (you can replace this with a larger corpus)
sample_corpus = """

In summary, auto-complete systems are a vital feature in modern digital interfaces, 
contributing to better user experiences, significant time savings, and overall increased efficiency. 
By understanding user behavior and leveraging advanced language models, these systems not only make our interactions with technology smoother but also enhance productivity and accessibility across various applications. 


"""


# Preprocess text and build n-gram model
def preprocess_text(text):
    sentences = nltk.sent_tokenize(text.lower())
    tokenized_sentences = [nltk.word_tokenize(sentence) for sentence in sentences]
    return tokenized_sentences


def build_ngram_model(corpus, n=2):
    ngrams_freq = defaultdict(Counter)
    for sentence in corpus:
        ngram_tuples = list(ngrams(sentence, n))
        for ngram in ngram_tuples:
            context = ngram[:-1]
            word = ngram[-1]
            ngrams_freq[context][word] += 1
    return ngrams_freq


def get_autocomplete_suggestions(context_words, ngram_model, n=2):
    context = tuple(context_words[-(n - 1):])
    suggestions = ngram_model.get(context, None)
    if suggestions:
        return suggestions.most_common(5)
    else:
        return []


# Preprocess the text and build the n-gram model
tokenized_corpus = preprocess_text(sample_corpus)
bigram_model = build_ngram_model(tokenized_corpus, n=2)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/autocomplete', methods=['POST'])
def autocomplete():
    input_text = request.json.get('input')
    context_words = nltk.word_tokenize(input_text.lower())
    suggestions = get_autocomplete_suggestions(context_words, bigram_model, n=2)

    return jsonify([word for word, freq in suggestions])


if __name__ == "__main__":
    nltk.download('punkt')
    app.run(debug=True)
from flask import Flask, render_template, request, jsonify
import nltk
from nltk.util import ngrams
from collections import defaultdict, Counter

app = Flask(__name__)

# Sample text corpus (you can replace this with a larger corpus)
sample_corpus = """
Autocomplete systems are powerful. Autocomplete is a function that predicts the next word based on the previous words. 
For example, when you type 'I love', the system might suggest 'you', 'programming', or 'coffee'. Autocomplete systems 
are used in search engines, text editors, and messaging applications.
"""


# Preprocess text and build n-gram model
def preprocess_text(text):
    sentences = nltk.sent_tokenize(text.lower())
    tokenized_sentences = [nltk.word_tokenize(sentence) for sentence in sentences]
    return tokenized_sentences


def build_ngram_model(corpus, n=2):
    ngrams_freq = defaultdict(Counter)
    for sentence in corpus:
        ngram_tuples = list(ngrams(sentence, n))
        for ngram in ngram_tuples:
            context = ngram[:-1]
            word = ngram[-1]
            ngrams_freq[context][word] += 1
    return ngrams_freq


def get_autocomplete_suggestions(context_words, ngram_model, n=2):
    context = tuple(context_words[-(n - 1):])
    suggestions = ngram_model.get(context, None)
    if suggestions:
        return suggestions.most_common(5)
    else:
        return []


# Preprocess the text and build the n-gram model
tokenized_corpus = preprocess_text(sample_corpus)
bigram_model = build_ngram_model(tokenized_corpus, n=2)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/autocomplete', methods=['POST'])
def autocomplete():
    input_text = request.json.get('input')
    context_words = nltk.word_tokenize(input_text.lower())
    suggestions = get_autocomplete_suggestions(context_words, bigram_model, n=2)

    return jsonify([word for word, freq in suggestions])


if __name__ == "__main__":
    nltk.download('punkt')
    app.run(debug=True)
